package Domain;

public class Tests {

    private static final double EPSILON = 0.0001;

    private boolean egal(double a, double b) {
        return Math.abs(a - b) < EPSILON;
    }

    public void teste_valide() throws Exception {
        ExpressionParser parser = new ExpressionParser(new String[]{"50+100*i", "+", "70+60*i", "+", "30+40*i", "+", "50+1*i"});
        NumereComplexe rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 200) && egal(rez.getIm(), 201))) {
            throw new IllegalStateException("test 1 fail");
        }

        parser = new ExpressionParser(new String[]{"100+100*i", "+", "-50+50*i", "+", "300-20*i", "+", "-146+70*i", "+", "0+1*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 204) && egal(rez.getIm(), 201))) {
            throw new IllegalStateException("test 2 fail");
        }

        parser = new ExpressionParser(new String[]{"-100+82*i", "+", "300-250*i", "+", "204-250*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 404) && egal(rez.getIm(), -418))) {
            throw new IllegalStateException("test 3 fail");
        }

        parser = new ExpressionParser(new String[]{"1000+250*i", "-", "582+50*i", "-", "14-1*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 404) && egal(rez.getIm(), 201))) {
            throw new IllegalStateException("test 4 fail");
        }

        parser = new ExpressionParser(new String[]{"1000+0*i", "-", "300+100*i", "-", "200+100*i", "-", "99+51*i", "-", "100+51*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 301) && egal(rez.getIm(), -302))) {
            throw new IllegalStateException("test 5 fail");
        }

        parser = new ExpressionParser(new String[]{"201+101*i", "*", "1+i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 100) && egal(rez.getIm(), 302))) {
            throw new IllegalStateException("test 6 fail");
        }

        parser = new ExpressionParser(new String[]{"91-131*i", "*", "2-i", "*", "1+i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 404) && egal(rez.getIm(), -302))) {
            throw new IllegalStateException("test 7 fail");
        }

        parser = new ExpressionParser(new String[]{"200-100*i", "*", "1+i", "*", "1-i", "*", "0+1*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 200) && egal(rez.getIm(), 400))) {
            throw new IllegalStateException("test 8 fail");
        }

        parser = new ExpressionParser(new String[]{"-3+405*i", "/", "1+i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 201) && egal(rez.getIm(), 204))) {
            throw new IllegalStateException("test 9 fail");
        }

        parser = new ExpressionParser(new String[]{"802-836*i", "/", "1+i", "/", "1-i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 401) && egal(rez.getIm(), -418))) {
            throw new IllegalStateException("test 10 fail");
        }

        parser = new ExpressionParser(new String[]{"2508+2418*i", "/", "1+i", "/", "1-i", "/", "3+0*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 418) && egal(rez.getIm(), 403))) {
            throw new IllegalStateException("test 11 fail");
        }

        parser = new ExpressionParser(new String[]{"2+3*i", "+", "5-6*i", "+", "-2+i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 5) && egal(rez.getIm(), -2))) {
            throw new IllegalStateException("test 12 fail");
        }

        parser = new ExpressionParser(new String[]{"46-29*i", "-", "-29+40*i", "-", "44+48*i", "-", "7+40*i"});
        rez = parser.creaza_expresie_finala().execute();
        if (!(egal(rez.getRe(), 24) && egal(rez.getIm(), -157))) {
            throw new IllegalStateException("test 13 fail");
        }

        System.out.println("Teste 1 ok!\n");
    }

    public void teste_invalide() throws Exception{
        try {
            ExpressionParser parser = new ExpressionParser(new String[]{""});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 1 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"2+3*i", "+"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 2 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"+", "2+3*i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 3 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"2+3*i","5-6*i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 4 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"2+3*i", "+", "+", "5-6*i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 5 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"2+3*j", "+", "1+i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 6 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"2+3*i", "%", "1+i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 7 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            ExpressionParser parser = new ExpressionParser(new String[]{"1+i", "/", "0+0*i"});
            NumereComplexe rez = parser.creaza_expresie_finala().execute();
            throw new Exception("test 8 failed");
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("Teste 2 ok!\n");
    }
}
