package Domain;

public class ExpressionFactory { //SINGLETON
    public static ExpressionFactory instance;
    private ExpressionFactory(){
        //aici trebuie ceva??
    }
    public static ExpressionFactory getInstance(){
        if(instance == null){
            instance = new ExpressionFactory();
        }
        return instance;
    }

    public ComplexExpression createExpression(Operation operation, NumereComplexe[] args){
        if(operation == Operation.ADDITION){
            Adunare adunare = new Adunare(args);
            return adunare;
        }
        else if (operation == Operation.SUBSTRACTION){
            Scadere scadere = new Scadere(args);
            return scadere;
        }
        else if (operation == Operation.MULTIPLICATION){
            return new Inmultire(args);
        }
        else if (operation == Operation.DIVISION){
            return new Impartire(args);
        }
        else{
            throw new IllegalArgumentException("Operatie necunoscuta");
        }
    }
}
