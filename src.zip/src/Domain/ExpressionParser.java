package Domain;

public class ExpressionParser {
    ExpressionFactory expressionFactory = ExpressionFactory.getInstance();
    public String[] args;
    Operation operation;

    public ExpressionParser(String[] args) {
        this.args = args;
    }

    public NumereComplexe converteste_in_numar(String arg){
        float re = 0;
        float im = 0;

        if(arg.endsWith("i")==false){
            //avem doar parte reala
            re = Float.parseFloat(arg);
            return new NumereComplexe(re,im);
        }

        int p = Math.max(arg.lastIndexOf('+'), arg.lastIndexOf('-'));

        String partImag;
        if (p <= 0) {
            // nu există separator (sau e doar semnul de pe poziția 0): totul e imaginar
            partImag = arg;
        } else {
            re = Float.parseFloat(arg.substring(0, p));
            partImag = arg.substring(p); // include semnul
        }

        partImag = partImag.substring(0, partImag.length() - 1); // scoate i
        if (partImag.endsWith("*")) {
            partImag = partImag.substring(0, partImag.length() - 1); // scoate *
        }
        //daca nr e 4-i, atunci ramane -, 1 nu se scrie
        if (partImag.equals("") || partImag.equals("+")) {
            im = 1;
        } else if (partImag.equals("-")) {
            im = -1;
        } else {
            im = Float.parseFloat(partImag);
        }

        return new NumereComplexe(re,im);
    }

    public void valid() throws Exception {
        if(args.length<=1) {
            throw new Exception("E nevoie de mai mult de un argument!");
        }
            String semn = args[1];

        if(args[args.length-1].equals("+") || args[args.length-1].equals("-") || args[args.length-1].equals("*") || args[args.length-1].equals("/")){
            throw new Exception("Expresia se termina cu un operator!");
        }

        if(semn.equals("+")){
            operation = Operation.ADDITION;
        }
        else if (semn.equals("-")){
            operation = Operation.SUBSTRACTION;
        }
        else if (semn.equals("*")){
            operation = Operation.MULTIPLICATION;
        }
        else if (semn.equals("/")){
            operation = Operation.DIVISION;
        }
        else {
            throw new Exception("Operator invalid");
        }

        for(int i = 3; i< args.length; i+=2){
            if (!(semn.equals(args[i]))){
                throw new Exception("Mai mult de un tip de operator detectat");
            }
        }

        for (int i = 0; i < args.length; i += 2) {
            try {
                converteste_in_numar(args[i]);
            } catch (NumberFormatException e) {
                throw new Exception("Tip invalid de argument");
            }
            if((i+1)<args.length){
                if((args[i].equals("+") || args[i].equals("*") || args[i].equals("-") || args[i].equals("/")) && (args[i+1].equals("+") || args[i+1].equals("*") || args[i+1].equals("-") || args[i+1].equals("/"))){
                    throw new Exception("Doi operatori sunt unul langa altul!");
                }
                try {
                    converteste_in_numar(args[i+1]);
                    throw new Exception("Doua numere sunt unul langa altul!");
                } catch (NumberFormatException _) {}
            }

        }

        if(args.length % 2 == 0){
            throw new Exception("Numar invalid de argumente");
        }
    }

    public ComplexExpression creaza_expresie_finala() throws Exception {
        this.valid();

        int lungime = args.length / 2 + 1;
        NumereComplexe[] argss = new NumereComplexe[lungime];
        for (int i = 0; i < args.length; i += 2) {
            argss[i / 2] = converteste_in_numar(args[i]);
            if((i/2 > 0) && (operation == Operation.DIVISION)){
                if (argss[i/2].getRe() == 0 && argss[i/2].getIm() == 0){
                    throw new Exception("Nu se poate imparti la zero!");
                }
            }
        }

        ComplexExpression complexExpression = expressionFactory.createExpression(operation, argss);
        return complexExpression;
    }
}




/**package Domain;

 public class ExpressionParser {
 ExpressionFactory expressionFactory = ExpressionFactory.getInstance();
 public String[] args;
 Operation operation;

 public ExpressionParser(String[] args) {
 this.args = args;
 }

 public NumereComplexe converteste_in_numar(String arg){
 float re = 0;
 float im = 0;

 if(arg.endsWith("i")==false){
 //avem doar parte reala
 re = Float.parseFloat(arg);
 return new NumereComplexe(re,im);
 }

 int p = Math.max(arg.lastIndexOf('+'), arg.lastIndexOf('-'));

 String partImag;
 if (p <= 0) {
 // nu există separator (sau e doar semnul de pe poziția 0): totul e imaginar
 partImag = arg;
 } else {
 re = Float.parseFloat(arg.substring(0, p));
 partImag = arg.substring(p); // include semnul
 }
 partImag = partImag.substring(0, partImag.length() - 1); //scoate i

 partImag = partImag.substring(0, partImag.length() - 1); // scoate i
 if (partImag.endsWith("*")) {
 partImag = partImag.substring(0, partImag.length() - 1); // scoate *
 }
 //daca nr e 4-i, atunci ramane -, 1 nu se scrie
 if (partImag.equals("") || partImag.equals("+")) {
 im = 1;
 } else if (partImag.equals("-")) {
 im = -1;
 } else {
 im = Float.parseFloat(partImag);
 }

 return new NumereComplexe(re,im);
 }

 public boolean valid(){
 if(args.length % 2 == 0){
 return false;
 }

 if(args.length<=1) {
 return false;
 }
 String semn = args[1];

 if(semn.equals("+")){
 operation = Operation.ADDITION;
 }
 else if (semn.equals("-")){
 operation = Operation.SUBSTRACTION;
 }
 else if (semn.equals("*")){
 operation = Operation.MULTIPLICATION;
 }
 else if (semn.equals("/")){
 operation = Operation.DIVISION;
 }
 else {
 return false;
 }

 for(int i = 3; i< args.length; i+=2){
 if (!(semn.equals(args[i]))){
 return false;
 }
 }

 for (int i = 0; i < args.length; i += 2) {
 try {
 converteste_in_numar(args[i]);
 } catch (NumberFormatException e) {
 return false;
 }
 }

 return true;
 }

 public ComplexExpression creaza_expresie_finala(){
 if (!valid()){
 throw new IllegalArgumentException("datele nu sunt valide");
 }

 int lungime = args.length / 2 + 1;
 NumereComplexe[] argss = new NumereComplexe[lungime];
 for (int i = 0; i < args.length; i += 2) {
 argss[i / 2] = converteste_in_numar(args[i]);
 }

 ComplexExpression complexExpression = expressionFactory.createExpression(operation, argss);
 return complexExpression;
 }


 }
 **/