package Domain;
//NumarComplex, având ca atribute re, im de tip real, iar ca metode operatiile
//definite pe multimea numerelor complexe: adunare, scadere, inmultire,
//impartire si conjugatul.
public class NumereComplexe {
    private float re;
    private float im;
    private char operator;
    public NumereComplexe(float re, float im){
        this.re = re;
        this.im = im;
    }

    public void conjugat(){
        this.im = this.im*(-1);
    }

    public NumereComplexe adunare(NumereComplexe b){
        float re_nou = this.re + b.re;
        float im_nou = this.im + b.im;
        NumereComplexe c = new NumereComplexe(re_nou, im_nou);
        return c;
    }

    public NumereComplexe scadere(NumereComplexe b){
        float re_nou = this.re - b.re;
        float im_nou = this.im -  b.im;
        NumereComplexe c = new NumereComplexe(re_nou, im_nou);
        return c;
    }

    public NumereComplexe inmultire (NumereComplexe b){
        //(a + bi) (c + di) = ac + adi + bci + (-1)bd = (ac-bd) + (ad+bc)*i
        float re_nou = this.re * b.re - this.im * b.im;
        float im_nou = this.re * b.im + this.im * b.re;
        NumereComplexe c = new NumereComplexe(re_nou, im_nou);
        return c;
    }

    public NumereComplexe impartire(NumereComplexe b) {
        // (a+bi)/(c+di) = (a+bi)(c-di) / (c^2+d^2)
        NumereComplexe bc = new NumereComplexe(b.re, -b.im);
        NumereComplexe numarator = this.inmultire(bc);
        float numitor = b.re * b.re + b.im * b.im;
        if (numitor == 0) {
            throw new ArithmeticException("Impartire la 0");
        }
        return new NumereComplexe(numarator.re / numitor, numarator.im / numitor);
    }

    private String format(float x) {
        if (x == (long) x) {
            return String.valueOf((long) x);   // 200.0 -> "200"
        }
        return String.valueOf(x);              // 0.44 -> "0.44"
    }

    @Override
    public String toString() {
        if (im < 0) {
            return format(re)  + format(im) + "i";
        }
        return format(re) + "+" + format(im) + "i";
    }

    public float getRe(){
        return this.re;
    }
    public float getIm(){
        return this.im;
    }
}
