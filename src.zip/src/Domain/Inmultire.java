package Domain;

public class Inmultire extends ComplexExpression{
    public Inmultire(NumereComplexe[] args) {
        super(Operation.MULTIPLICATION, args);
    }

    @Override
    public NumereComplexe executeOneOperation(NumereComplexe a, NumereComplexe b) {
        return a.inmultire(b);
    }
}

