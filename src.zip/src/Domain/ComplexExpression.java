package Domain;

public abstract class ComplexExpression {
    protected Operation operation; //astfel le vad si copii
    protected NumereComplexe[] args;

    public ComplexExpression(Operation operation, NumereComplexe[] args) {
        this.operation = operation;
        this.args = args;
    }

    public abstract NumereComplexe executeOneOperation(NumereComplexe a, NumereComplexe b);

    public NumereComplexe execute(){
        //executa operatia definita anterior intre termenii din argumente, 2 cate 2
        NumereComplexe rez = args[0];
        for(int i = 1; i< args.length; i++){
            rez = executeOneOperation(rez, args[i]);
        }
        return rez;
    }
}

