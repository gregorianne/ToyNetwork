package Domain;

enum Operation{
    ADDITION,
    SUBSTRACTION,
    MULTIPLICATION,
    DIVISION
}