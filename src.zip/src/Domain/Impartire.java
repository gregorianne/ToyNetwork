package Domain;

public class Impartire extends ComplexExpression{
    public Impartire(NumereComplexe[] args) {
        super(Operation.DIVISION, args);
    }

    @Override
    public NumereComplexe executeOneOperation(NumereComplexe a, NumereComplexe b) {
        return a.impartire(b);
    }
}
