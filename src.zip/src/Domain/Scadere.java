package Domain;

public class Scadere extends ComplexExpression{
    public Scadere(NumereComplexe[] args) {
        super(Operation.SUBSTRACTION, args);
    }

    @Override
    public NumereComplexe executeOneOperation(NumereComplexe a, NumereComplexe b) {
        return a.scadere(b);
    }
}

