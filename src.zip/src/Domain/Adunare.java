package Domain;

public class Adunare extends ComplexExpression{
    public Adunare(NumereComplexe[] args) {
        super(Operation.ADDITION, args);
    }

    @Override
    public NumereComplexe executeOneOperation(NumereComplexe a, NumereComplexe b) {
        return a.adunare(b);
    }
}


