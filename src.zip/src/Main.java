//Se citesc, ca parametri în linia de comanda, separati prin spatiu, mai multe numere
//complexe de forma a+b*i și o operație, sub forma unui operator (+, - , *, /).
//. Sa se verifice dacă parametri citiți în linia de comanda, separați prin spațiu, reprezintă o
//expresie aritmetica de forma:
//n 1 op n2 op ... op nk ,
import Domain.*;

public class Main {
    public static void main() throws Exception {
        //String[] args = {"50+100*i", "+", "+", "70+60*i", "+", "30+40*i", "+", "50+1*i"};
        String[] args = {"91-131*i", "*", "2-i", "*", "1+i"};
        ExpressionParser parser = new ExpressionParser(args);
        ComplexExpression expr = parser.creaza_expresie_finala();
        System.out.println(expr.execute());

        Tests test = new Tests();
        test.teste_valide();
        test.teste_invalide();

    }
}